-dontwarn javax.annotation.**

